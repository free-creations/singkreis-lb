skUserGreeting
==============

A joomla plugin used on the site "www.singkreis-lb.de".


This module shows the  name of the user. For guest users it displays nothing.