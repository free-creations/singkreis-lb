This is an adapted version of the Joomla user-profile-plugin.

see:
http://www.inmotionhosting.com/support/edu/joomla-25/user-profile/copy-user-profile-plugin
