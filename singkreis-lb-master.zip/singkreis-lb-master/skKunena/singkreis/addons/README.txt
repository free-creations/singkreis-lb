replace the file
"libraries/kunena/bbcode/bbcode.php"
by the file "bbcode.php" provided in this directory.
