
This template is an attempt to make the kunena Forum more user friendly an more responsive.


Installation
------------
Do not forget to override to bbcode module
./libraries/kunena/bbcode/bbcode.php